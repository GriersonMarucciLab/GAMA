#!/bin/bash -login

# This script was automatically created by Oliver Chalkley's whole-cell modelling suite and is based on scripts that he created.

## Job name
#SBATCH --job-name=big_mix_of_split_mixes_bg_4_gen40

## What account the simulations are registered to
#SBATCH -A Flex1

## Resource request
#SBATCH --ntasks=1 # No. of cores
#SBATCH --time=0-30:00:00
#SBATCH -p cpu

## Job array request
#SBATCH --array=1-200

## designate output and error files
#SBATCH --output=/projects/flex1/database/wcm_suite/output/kos/genetic_algorithms/big_mix_of_split_mixes/bg_4_gen40_%A_%a.out
#SBATCH --error=/projects/flex1/database/wcm_suite/output/kos/genetic_algorithms/big_mix_of_split_mixes/bg_4_gen40_%A_%a.err

# print some details about the job
echo "The Array TASK ID is: ${SLURM_ARRAY_TASK_ID}"
echo "The Array JOB ID is: ${SLURM_ARRAY_JOB_ID}"
echo Running on host `hostname`
echo Time is `date`
echo Directory is `pwd`

# load required modules
module load apps/matlab-r2013a
echo "Modules loaded:"
module list

# create the master directory variable
master=/panfs/panasas01/emat/oc13378/WholeCell/wc/mg/WholeCell-master

# create output directory
base_outDir=/projects/flex1/database/wcm_suite/output/kos/genetic_algorithms/big_mix_of_split_mixes/bg_4_gen40

# collect the KO combos
ko_list=/projects/flex1/database/wcm_suite/runFiles/kos/genetic_algorithms/big_mix_of_split_mixes/bg_4_gen40/ko_sets.list
ko_dir_names=/projects/flex1/database/wcm_suite/runFiles/kos/genetic_algorithms/big_mix_of_split_mixes/bg_4_gen40/ko_set_names.list

# Get all the gene KOs and output folder names
for i in `seq 1 1`
do
    Gene[${i}]=$(awk NR==$((1*(${SLURM_ARRAY_TASK_ID}-1)+${i})) ${ko_list})
    unique_ko_dir_name[${i}]=$(awk NR==$((1*(${SLURM_ARRAY_TASK_ID}-1)+${i})) ${ko_dir_names})
done

# go to master directory
cd ${master}

# NB have limited MATLAB to a single thread
options="-nodesktop -noFigureWindows -nosplash -singleCompThread"

# run 1 simulations in parallelecho "Running simulations (single threaded) in parallel - let's start the timer!"
start=`date +%s`

# create all the directories for the diarys (the normal output will be all mixed up cause it's in parrallel!)
for i in `seq 1 1`
do
    for j in `seq 1 1`
    do
        specific_ko="$(echo ${Gene[${i}]} | sed 's/{//g' | sed 's/}//g' | sed "s/'//g" | sed 's/"//g' | sed 's/,/-/g')/${j}"
        mkdir -p ${base_outDir}/${unique_ko_dir_name[${i}]}/diary${j}
        matlab ${options} -r "diary('${base_outDir}/${unique_ko_dir_name[${i}]}/diary${j}/diary.out');addpath('${master}');setWarnings();setPath();runSimulation('runner','koRunner','logToDisk',true,'outDir','${base_outDir}/${unique_ko_dir_name[${i}]}/${j}','jobNumber',$((no_of_repetitions_of_each_ko*no_of_unique_kos_per_array_job*(${SLURM_ARRAY_TASK_ID}-1)+no_of_unique_kos_per_array_job*(${i}-1)+${j})),'koList',{{${Gene[${i}]}}});diary off;exit;" &
    done
done
wait

end=`date +%s`
runtime=$((end-start))
echo "$((${no_of_unique_kos_per_array_job}*${no_of_repetitions_of_each_ko})) simulations took: ${runtime} seconds."